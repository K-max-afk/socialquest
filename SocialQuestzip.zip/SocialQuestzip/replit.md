# SocialQuest

Proyecto educativo interactivo sobre Economía Mundial y Comercio Internacional.

## Stack

Static web app — HTML, CSS, JavaScript. No build step, no dependencies.

## Running the app

```
python3 -m http.server 5000
```

Served on port 5000. Open the preview to play.

## Files

- `index.html` — app structure and content
- `style.css` — styles
- `script.js` — quiz logic

## User preferences

_None recorded yet._
